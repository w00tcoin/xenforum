/**
* Prestashop Addons | Module by: <App1Pro>
*
* @author    Chuyen Nguyen [App1Pro].
* @copyright Chuyenim@gmail.com
* @license   http://app1pro.com/license.txt
*/
// Indonesian
jQuery.timeago.settings.strings = {
  prefixAgo: null,
  prefixFromNow: null,
  suffixAgo: "yang lalu",
  suffixFromNow: "dari sekarang",
  seconds: "kurang dari semenit",
  minute: "sekitar satu menit",
  minutes: "%d menit",
  hour: "sekitar sejam",
  hours: "sekitar %d jam",
  day: "sehari",
  days: "%d hari",
  month: "sekitar sebulan",
  months: "%d bulan",
  year: "sekitar setahun",
  years: "%d tahun"
};
